
# Changelog
### Feedback from Part 2
1. From the feedback I got from my lecturer, I was told to add references. I added a full Harvard-style reference list at the end of this README for every source I used (form validation, slideshow, lightbox, accordion, meta tags, SEO, FormSubmit and images).

### Other improvements to Part 2
2. Removed inline styles from all pages (logo size, image sizes and body background colours) and moved them into styles1.css so all styling is in the external stylesheet.
3. Added `<meta charset>` and `<meta name="viewport">` to every page. Without the viewport tag the 768px and 480px media queries did not work properly on phones.
4. Improved contrast: navigation links (beige on light pink) and h3 headings (antiquewhite on blanchedalmond) are now dark brown.
5. Added descriptive alt text to all images.
6. Replaced the "|" characters in the navigation with CSS spacing and changed the homepage h3 to an h2 so headings follow a proper order.
7. Made the opening hours consistent: contact.html said Mon-Sat 11AM-7PM but News.html said we are closed Sundays and Mondays. Both now show Tue-Fri 11AM-6PM and Sat 10AM-7PM.
8. Updated this README (the CSS is 150 lines, not 72) and replaced the GitHub link placeholder.

### New in Part 3
9. Created JS/script.js and linked it on every page with `defer`.
10. Added the slideshow and lightbox to gallery.html (the lightbox also works on the homepage and About Us images).
11. Added the accordion FAQ to about us.html.
12. Menu.html and News.html now load their content from JavaScript arrays; added search, filter and sort to the menu.
13. Created enquiry.html and added JavaScript validation and a cost/availability response.
14. Added the contact form to contact.html with validation and AJAX email submission.
15. Added the date and time to the footer of all pages.
16. Added robots.txt, sitemap.xml, meta descriptions, keywords and structured data.
17. Added the Part 3 CSS (sections 10 to 19) to the bottom of styles1.css.

## How to Run
1. Download the ZIP and unzip it
2. Open index.html in Chrome
Live site: https://ondwela-code.github.io/gundos-eatery/

## Responsive Design Tested On
- Desktop: 1024px+
- Tablet: 768px
- Mobile: 480px and 320px

## References
- FormSubmit (n.d.) *FormSubmit: AJAX form submission*. Available at: https://formsubmit.co/ (Accessed: 2 November 2026).
- Google Search Central (n.d.) *SEO starter guide*. Available at: https://developers.google.com/search/docs/fundamentals/seo-starter-guide (Accessed: 2 November 2026).
- MDN Web Docs (n.d.) *Constraint validation*. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Constraint_validation (Accessed: 2 November 2026).
- Pexels (n.d.) *Free stock photos*. Available at: https://www.pexels.com/ (Accessed: 2 November 2026). Other images are own business photos.
- W3Schools (n.d.) *HTML meta tag*. Available at: https://www.w3schools.com/tags/tag_meta.asp (Accessed: 2 November 2026).
- W3Schools (n.d.) *HTML forms validation*. Available at: https://www.w3schools.com/htmlcss/htmlcss_forms_validation.asp (Accessed: 2 November 2026).
- W3Schools (n.d.) *How to create a lightbox*. Available at: https://www.w3schools.com/howto/howto_js_lightbox.asp (Accessed: 2 November 2026).
- W3Schools (n.d.) *How to create a slideshow*. Available at: https://www.w3schools.com/howto/howto_js_slideshow.asp (Accessed: 2 November 2026).
- W3Schools (n.d.) *How to create an accordion*. Available at: https://www.w3schools.com/howto/howto_js_accordion.asp (Accessed: 2 November 2026).
- W3Schools (n.d.) *CSS Flexbox* and *CSS Grid*. Available at: https://www.w3schools.com/css/ (Accessed: 2 November 2026).

## GitHub Link
https://github.com/Ondwela-code/gundos-eatery