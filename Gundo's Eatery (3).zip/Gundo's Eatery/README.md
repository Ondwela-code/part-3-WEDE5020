
# Gundo's Eatery - WEDE5020 Part 3
Student: Ondwela Mathobo
Student Number: ST10519648
Module: WEDE5020

## Project Overview
Gundo's Eatery is a small local eatery in Kagiso, Krugersdorp, founded in 2023 by Mercy Maluga. The website shows our story, menu, gallery, news and contact details so customers can view our Kota and drinks menu and get in touch.

## Website Structure
- index.html - Homepage
- about us.html - Our story and FAQ accordion
- Menu.html - Menu loaded with JavaScript (search, filter, sort)
- gallery.html - Slideshow, lightbox gallery and video
- News.html - News and specials loaded with JavaScript
- enquiry.html - Enquiry form that returns a cost and availability response
- contact.html - Contact details, map and contact form (sent by email with AJAX)
- CSS/styles1.css, JS/script.js, robots.txt, sitemap.xml

## Part 3 Features
1. Slideshow with previous/next buttons, pause/play, caption, counter and auto-advance
2. Lightbox that opens any photo larger, with arrow buttons, keyboard keys (Esc, left, right) and captions
3. Accordion FAQ on the About Us page
4. Dynamic menu and news content created with JavaScript (DOM manipulation)
5. Search, category filter and sort on the menu
6. JavaScript form validation with error messages (name, email, SA phone number, subject, message, quantity, date)
7. Contact form sends an email using an AJAX request (FormSubmit)
8. Enquiry form calculates the cost and checks availability (closed Sunday and Monday)
9. Live date and time in the footer of every page
10. CSS animations and transitions (page fade-in, accordion, slideshow fade, lightbox zoom, hover effects)
11. SEO: unique titles and meta descriptions, keywords, heading structure, image alt text, internal links, mobile friendly, robots.txt, sitemap.xml, local business structured data
12. Page speed and security: scripts loaded with defer, lazy-loaded images, video metadata only, user text inserted with textContent, validated input

