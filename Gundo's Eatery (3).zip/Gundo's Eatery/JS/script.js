
"use strict";

/* ===== Data: add your remaining menu items and news posts here ===== */
const menuItems = [
  { name: "Kota Full House", category: "Meals", price: 45, desc: "Chips, polony, cheese, egg, Russian" },
  { name: "Kota Burger", category: "Meals", price: 40, desc: "Chips, beef burger, cheese, egg, Russian" },
  { name: "Soft Drinks", category: "Cool Drinks", price: 15, desc: "Chilled soft drinks" },
  { name: "Fresh Juice", category: "Cool Drinks", price: 20, desc: "Freshly made juice" }
];
const newsPosts = [
  { type: "Special", title: "New Special!", text: "Kota Full House on special for R40 every Friday!" },
  { type: "Update", title: "New trading hours", text: "We are now open on Saturdays from 10AM-7PM. We do not open on Sundays and Mondays." }
];
// IMPORTANT: replace with the real email address that must receive the contact messages.
const RECIPIENT_EMAIL = "your-email@example.com";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

/* ===== Footer date and time ===== */
function updateDateTime() {
  const el = $("#datetime");
  if (!el) return;
  el.textContent = new Date().toLocaleString("en-ZA", {
    weekday: "long", year: "numeric", month: "long", day: "numeric",
    hour: "2-digit", minute: "2-digit", second: "2-digit"
  });
}

/* ===== Mark the current page in the navigation ===== */
function markCurrentPage() {
  const page = location.pathname.split("/").pop() || "index.html";
  $$("nav a").forEach(a => {
    if (a.getAttribute("href") === page) a.setAttribute("aria-current", "page");
  });
}

/* ===== Accordion (About Us FAQ) ===== */
function initAccordion() {
  $$(".accordion-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const panel = btn.nextElementSibling;
      const open = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", String(!open));
      panel.hidden = open;
    });
  });
}

/* ===== Slideshow (uses the photos in the gallery grid) ===== */
function initSlideshow() {
  const img = $("#slideImage");
  if (!img) return;
  const slides = $$(".gallery img");
  const caption = $("#slideCaption"), counter = $("#slideCounter"), playBtn = $("#playBtn");
  let i = 0, timer = null;

  function show(n) {
    i = (n + slides.length) % slides.length;
    img.style.opacity = 0;
    setTimeout(() => {
      img.src = slides[i].src;
      img.alt = slides[i].alt;
      img.style.opacity = 1;
    }, 250);
    caption.textContent = slides[i].dataset.caption || slides[i].alt;
    counter.textContent = `${i + 1} / ${slides.length}`;
  }
  function start() { timer = setInterval(() => show(i + 1), 4000); playBtn.textContent = "Pause slideshow"; }
  function stop() { clearInterval(timer); timer = null; playBtn.textContent = "Play slideshow"; }

  $(".slide-btn.next").addEventListener("click", () => show(i + 1));
  $(".slide-btn.prev").addEventListener("click", () => show(i - 1));
  playBtn.addEventListener("click", () => (timer ? stop() : start()));
  show(0);
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) stop(); else start();
}

/* ===== Lightbox (built with the DOM, works on any .zoomable image) ===== */
function initLightbox() {
  const group = $$(".gallery img");
  const box = document.createElement("div");
  box.className = "lightbox";
  box.hidden = true;
  box.setAttribute("role", "dialog");
  box.setAttribute("aria-modal", "true");
  box.setAttribute("aria-label", "Image viewer");
  box.innerHTML = '<button type="button" class="lb-close" aria-label="Close">&times;</button>' +
    '<button type="button" class="lb-nav lb-prev" aria-label="Previous image">&#10094;</button>' +
    '<figure><img alt=""><figcaption></figcaption></figure>' +
    '<button type="button" class="lb-nav lb-next" aria-label="Next image">&#10095;</button>';
  document.body.appendChild(box);

  const lbImg = $("img", box), lbCap = $("figcaption", box);
  let list = [], idx = 0, opener = null;

  function show(n) {
    idx = (n + list.length) % list.length;
    const s = list[idx];
    lbImg.src = s.src;
    lbImg.alt = s.alt;
    lbCap.textContent = s.dataset.caption || s.alt;
    $$(".lb-nav", box).forEach(b => (b.style.display = list.length > 1 ? "" : "none"));
  }
  function open(el) {
    opener = el;
    list = group.some(s => s.src === el.src) ? group : [el];
    show(Math.max(0, list.findIndex(s => s.src === el.src)));
    box.hidden = false;
    document.body.style.overflow = "hidden";
    $(".lb-close", box).focus();
  }
  function close() {
    box.hidden = true;
    document.body.style.overflow = "";
    if (opener) opener.focus();
  }

  $$(".zoomable").forEach(el => (el.tabIndex = 0));
  document.addEventListener("click", e => {
    const el = e.target.closest(".zoomable");
    if (el) open(el);
  });
  box.addEventListener("click", e => {
    if (e.target === box || e.target.closest(".lb-close")) close();
    else if (e.target.closest(".lb-prev")) show(idx - 1);
    else if (e.target.closest(".lb-next")) show(idx + 1);
  });
  document.addEventListener("keydown", e => {
    if (box.hidden) {
      if (e.key === "Enter" && e.target.classList && e.target.classList.contains("zoomable")) open(e.target);
      return;
    }
    if (e.key === "Escape") close();
    if (e.key === "ArrowLeft") show(idx - 1);
    if (e.key === "ArrowRight") show(idx + 1);
  });
}

/* ===== Menu: dynamic content with search, filter and sort ===== */
function initMenu() {
  const list = $("#menuList");
  if (!list) return;
  const search = $("#menuSearch"), cat = $("#menuCategory"), sort = $("#menuSort"), count = $("#menuCount");

  function render() {
    const term = search.value.trim().toLowerCase();
    const items = menuItems.filter(m =>
      (cat.value === "all" || m.category === cat.value) &&
      (m.name + " " + m.desc).toLowerCase().includes(term));
    if (sort.value === "az") items.sort((a, b) => a.name.localeCompare(b.name));
    if (sort.value === "low") items.sort((a, b) => a.price - b.price);
    if (sort.value === "high") items.sort((a, b) => b.price - a.price);

    list.replaceChildren(...items.map(m => {
      const card = document.createElement("article");
      card.className = "menu-card";
      card.innerHTML = `<h3>${m.name}</h3><p>${m.desc}</p><p class="price">R${m.price}</p>`;
      return card;
    }));
    count.textContent = items.length ? `${items.length} item(s) shown` : "No items match your search. Try a different word.";
  }
  [search, cat, sort].forEach(el => el.addEventListener("input", render));
  render();
}

/* ===== News: dynamic posts ===== */
function initNews() {
  const box = $("#newsList");
  if (!box) return;
  box.replaceChildren(...newsPosts.map(p => {
    const post = document.createElement("article");
    post.className = "news-card";
    post.innerHTML = `<span class="tag">${p.type}</span><h2>${p.title}</h2><p>${p.text}</p>`;
    return post;
  }));
}

/* ===== Form validation (shared by contact and enquiry) ===== */
const rules = {
  name: v => /^[A-Za-zÀ-ÖØ-öø-ÿ][A-Za-zÀ-ÖØ-öø-ÿ '\-]{1,79}$/.test(v) ? "" : "Enter a valid name (letters only, 2 to 80 characters).",
  email: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? "" : "Enter a valid email address, e.g. name@example.com.",
  phone: v => /^(\+27|0)[0-9]{9}$/.test(v.replace(/[\s()-]/g, "")) ? "" : "Enter a valid South African number, e.g. 082 123 4567.",
  subject: v => v ? "" : "Choose a subject.",
  message: v => v.length >= 10 && v.length <= 1000 ? "" : "Write between 10 and 1000 characters.",
  service: v => v ? "" : "Choose an item.",
  quantity: v => Number.isInteger(Number(v)) && v !== "" && v >= 1 && v <= 100 ? "" : "Enter a whole number from 1 to 100.",
  date: v => {
    if (!v) return "Choose a date.";
    const today = new Date(); today.setHours(0, 0, 0, 0);
    return new Date(v + "T00:00") >= today ? "" : "The date cannot be in the past.";
  }
};

function setError(field, msg) {
  let e = field.nextElementSibling;
  if (!e || !e.classList.contains("error")) {
    e = document.createElement("small");
    e.className = "error";
    e.id = field.id + "-error";
    field.after(e);
  }
  e.textContent = msg;
  field.setAttribute("aria-invalid", msg ? "true" : "false");
  if (msg) field.setAttribute("aria-describedby", e.id);
}

function validateForm(form) {
  let first = null;
  [...form.elements].forEach(f => {
    const rule = rules[f.id];
    if (!rule) return;
    const msg = rule(f.value.trim());
    setError(f, msg);
    if (msg && !first) first = f;
  });
  if (first) first.focus();
  return !first;
}

function liveValidate(form) {
  form.addEventListener("focusout", e => {
    const rule = rules[e.target.id];
    if (rule) setError(e.target, rule(e.target.value.trim()));
  });
}

/* ===== Contact form: validation + AJAX email ===== */
function initContactForm() {
  const form = $("#contactForm");
  if (!form) return;
  const btn = $("button[type=submit]", form), status = $("#formStatus");
  liveValidate(form);

  form.addEventListener("submit", async e => {
    e.preventDefault();
    if (!validateForm(form)) { status.textContent = "Please fix the highlighted fields."; return; }
    btn.disabled = true;
    btn.textContent = "Sending...";
    status.textContent = "Sending your message...";
    try {
      const data = Object.fromEntries(new FormData(form));
      data._subject = "New Gundo's Eatery contact message";
      data._template = "table";
      const res = await fetch("https://formsubmit.co/ajax/" + encodeURIComponent(RECIPIENT_EMAIL), {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify(data)
      });
      const result = await res.json();
      if (res.ok && (result.success === true || result.success === "true")) {
        status.textContent = "Thank you! Your message was sent.";
        form.reset();
        $$(".error", form).forEach(x => (x.textContent = ""));
      } else {
        throw new Error(result.message || "The email service did not confirm the message.");
      }
    } catch (err) {
      console.error("Form error:", err);
      status.textContent = "Your message was not sent. Check your connection and try again, or call us on 071 444 0987.";
    } finally {
      btn.disabled = false;
      btn.textContent = "Send message";
    }
  });
}

/* ===== Enquiry form: validation + cost and availability response ===== */
function initEnquiryForm() {
  const form = $("#enquiryForm");
  if (!form) return;
  const service = $("#service"), dateInput = $("#date"), status = $("#formStatus");
  menuItems.forEach(m => service.add(new Option(`${m.name} - R${m.price}`, m.name)));
  dateInput.min = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  liveValidate(form);

  form.addEventListener("submit", e => {
    e.preventDefault();
    if (!validateForm(form)) { status.textContent = "Please fix the highlighted fields."; return; }
    const first = $("#name").value.trim().split(" ")[0];
    const item = menuItems.find(m => m.name === service.value);
    const qty = Number($("#quantity").value);
    const when = new Date(dateInput.value + "T00:00");
    const day = when.getDay();
    const nice = when.toLocaleDateString("en-ZA", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    const total = item.price * qty;

    if (day === 0 || day === 1) {
      status.textContent = `Sorry ${first}, we are closed on Sundays and Mondays. Please choose a date from Tuesday to Saturday.`;
    } else if (qty > 20) {
      status.textContent = `Thanks ${first}! ${qty} x ${item.name} comes to R${total}. Large orders must be confirmed, so please call 071 444 0987 to check availability for ${nice}.`;
    } else {
      const hours = day === 6 ? "10AM-7PM" : "11AM-6PM";
      status.textContent = `Thanks ${first}! ${qty} x ${item.name} costs R${total}. We are available on ${nice} (open ${hours}) at 12731 Kagiso, Krugersdorp.`;
    }
  });
}

/* ===== Start everything ===== */
updateDateTime();
setInterval(updateDateTime, 1000);
markCurrentPage();
initAccordion();
initSlideshow();
initLightbox();
initMenu();
initNews();
initContactForm();
initEnquiryForm();